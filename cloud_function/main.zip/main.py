def hello_world(request):
    return "Hello from Cloud Function!"